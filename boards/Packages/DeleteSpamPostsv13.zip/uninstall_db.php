<?php
/*******************************************************************************
This script will remove the settings added by the Delete Spam Posts mod.

	Upload this file to the folder your forums are in and access
	it directly, with a URL like the following:
		http://www.yourdomain.tld/forum/uninstall_db.php (or similar.)

*******************************************************************************/
// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

if(isset($smcFunc))
{
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}settings
		WHERE variable IN ({array_string:vars})',
		array(
			'vars' => array(
				'deletespampost_enable',
				'deletespampost_message',
				'deletespampost_dock_karma',
				'deletespampost_to_recycle',
			)
		)
	);

	echo 'The database settings have been deleted. <br /><br />Don\'t forget to remove this file from the server.';
}
else
{
	db_query("
		DELETE FROM {$db_prefix}settings
		WHERE variable IN (
			'deletespampost_enable', 
			'deletespampost_message', 
			'deletespampost_dock_karma', 
			'deletespampost_to_recycle'
		)", __FILE__, __LINE__);

	echo 'The database settings have been deleted. <br /><br />Don\'t forget to remove this file from the server.';
}

?>