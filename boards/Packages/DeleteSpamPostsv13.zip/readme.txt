Name: Delete Spam Posts
Author: Kays
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
This mod will allow a moderator or admin to delete a spam post. Automatically leaving a messge and reducing the member's post count by one. With the option to also award the member bad karma

These options are selectable in the Admin CP under the Posts and Topics option. The display message can be edited there also.

