Name: Delete Spam Posts
Author: Kays
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
This mod will allow a moderator or admin to delete a spam post and reduce the member's post count by one. With the option to also award the member bad karma
It also logs the deleted message in the Moderator's logs. As well it will log any message 
which has been modified by a mod or admin. This is selectable in the Admin CP under the Posts and Topics option.
The display message can be edited there also.

