<?php

if(isset($smcFunc))
{
	$smcFunc['db_insert']('ignore',
		'{db_prefix}settings',
		array('variable' => 'string', 'value' => 'string'),
		array(
			array('deletespampost_enable', '1'),
			array('deletespampost_message', '[b]This message has been deleted by {SpamCop} as spam![/b] [i]{Spammer}\'s post count has been reduced by 1.[/i]'),
		),
		array('variable')
	);
}
else
{
	db_query("
		INSERT IGNORE INTO {$db_prefix}settings 
		VALUES ('deletespampost_enable', '1')
	", __FILE__, __LINE__);
}

?>